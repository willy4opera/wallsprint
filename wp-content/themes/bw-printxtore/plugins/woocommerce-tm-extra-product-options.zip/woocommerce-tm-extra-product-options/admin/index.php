<?php
/**
 * Direct access security.
 *
 * @package Extra Product Options
 */

die();
